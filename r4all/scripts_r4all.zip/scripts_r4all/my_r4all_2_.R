#' ---
#' title: "[Getting Started with R](https://github.com/haruosuz/books/tree/master/r4all)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url)
if(!file.exists(filename)){ download.file(url = url, destfile = filename); unzip(zipfile = filename); }

#' # 2 Getting Your Data into R
#' ## 2.1 Getting data ready for R
#' ### 2.1.1 SETTING UP YOUR OWN DATA
#' - https://id.fnshr.info/2017/01/09/tidy-data-intro/
#' - [12 Tidy data | R for Data Science](https://github.com/haruosuz/books/blob/master/r4ds/README.md#12-tidy-data)
#' ![https://r4ds.had.co.nz/tidy-data.html](https://d33wubrfki0l68.cloudfront.net/6f1ddb544fc5c69a2478e444ab8112fb0eea23f8/91adc/images/tidy-1.png)
#' 
#' #### An exercise in data preparation
#' - Top Tip 1. missing data: NA (Not Available)
#' - Top Tip 2. comma-separated values (.csv file)
#' 
#' ### 2.1.2 SOMEONE ELSE’S DATA?
#' ## 2.2 Getting your data into R
#' http://r4all.org/books/datasets/
#' 
#' ### 2.2.1 IMPORTING DATA, PREPARATION
#' some annotation, the libraries, and the brain clearer
#' 
# Clear the decks
rm(list = ls())

# libraries I always use.
library(tidyverse)

#' ### 2.2.2 METHOD 1: THE IMPORT DATASET TOOL
#' Import Dataset (Figure 2.5)
#' 
#library(readr)
#compensation <- read_csv("datasets-master/compensation.csv")
#View(compensation)

#' ### 2.2.3 METHOD 2: THE file.choose() FUNCTION
#file.choose()
#' ### 2.2.4 METHOD 3: DANCING WITH THE IMPORT DEVIL
#' 
#' Session -> Set Working Directory -> Choose Directory.
#' 
#' ### 2.2.5 METHOD 4: PUT YOUR DATA IN THE SAME PLACE AS YOUR SCRIPT
#' 
compensation <- read.csv("datasets-master/compensation.csv", stringsAsFactors=TRUE)

#' ## 2.3 Checking that your data are your data
names(compensation)
head(compensation)
tail(compensation)
dim(compensation)
str(compensation)

#' ### 2.3.1 YOUR FIRST INTERACTION WITH dplyr
# dplyr viewing of data
#library(dplyr)

# glimpse and tbl_df
glimpse(compensation)
tibble::as_tibble(compensation) # tbl_df(compensation)

#' ## 2.4 Basic trouble shooting while importing data
#' ## 2.5 Summing up
sessionInfo()
