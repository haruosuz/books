#' ## 5.2 χ2 contingency table analysis
#' ### 5.2.1 THE DATA: LADYBIRDS
#' 
# My First Chi-square contingency analysis

# Clear the decks
rm(list = ls())

#+ message = FALSE
# libraries I always use.
#library(dplyr)
#library(ggplot2)
library(tidyverse)

# import the data
lady <- read.csv("datasets-master/ladybirds_morph_colour.csv", stringsAsFactors=TRUE)

# Check it out
glimpse(lady)

#' ### 5.2.2 ORGANIZING THE DATA FOR PLOTTING AND ANALYSIS
#' 
totals <- lady %>% 
  group_by(Habitat, morph_colour) %>% 
  summarize(total.number = sum(number))

ggplot(totals, aes(x = Habitat, y = total.number, fill = morph_colour)) + 
  geom_bar(stat = 'identity', position = 'dodge')

#' Figure 5.1
#' 
#' ### 5.2.3 NEW ggplot() DETAIL
#' 
#' ### 5.2.4 FIXING THE COLOURS

ggplot(totals, aes(x = Habitat, y = total.number, fill = morph_colour)) + 
  geom_bar(stat = 'identity', position = 'dodge') + 
  scale_fill_manual(values = c(black = "black", red = "red"))

#' Figure 5.2
#' 
#' ### 5.2.5 INTERPRETING THE GRAPH (GUESS THE ANSWER BEFORE WE DO STATS)
#' ### 5.2.6 MAKING THE χ2 TEST

totals

lady.mat <- xtabs(number ~ Habitat + morph_colour, data = lady)
lady.mat

chisq.test(lady.mat)

#' ‘We tested the hypothesis that there is an association between colour morphs of ladybirds and industrial and rural habitats. Ladybird colour morphs are not equally distributed in the two habitats (χ 2 = 19.1, df = 1, p < 0.001), with black morphs being more frequent in industrial habitats and red morphs more frequent in rural habitats (Figure 5.1).’

lady.chi <- chisq.test(lady.mat)
names(lady.chi)
lady.chi$expected
