#' ## 5.4 Introducing...linear models
#' ## 5.5 Simple linear regression
#' - response (dependent) variable—plant growth rate
#' - explanatory (independent) variable—soil moisture content
#' 
#' ### 5.5.1 GETTING AND PLOTTING THE DATA
#' 
#+ message = FALSE
# libraries I need (no need to install...)
library(tidyverse)

# Clear the decks
rm(list = ls())

# get the data
plant_gr <- read.csv('datasets-master/plant.growth.rate.csv', stringsAsFactors=TRUE)

# check out the data
glimpse(plant_gr)

ggplot(plant_gr, aes(x = soil.moisture.content, y = plant.growth.rate)) + 
  geom_point() + 
  ylab("Plant Growth Rate (mm/week)") + 
  theme_bw()

#' Figure 5.4
#' 
#' ### 5.5.2 INTERPRETING THE FIGURE: BIOLOGICAL INSIGHT
#' ### 5.5.3 MAKING A SIMPLE LINEAR REGRESSION HAPPEN
#' 
model_pgr <- lm(plant.growth.rate ~ soil.moisture.content, data = plant_gr)

#' ### 5.5.4 ASSUMPTIONS FIRST
#' 
#plot(model_pgr)

#install.packages("ggfortify")
library(ggfortify)
autoplot(model_pgr, smooth.colour = NA)
#' Figure 5.5
#' 
#' ### 5.5.5 NOW THE INTERPRETATION
#' 
anova(model_pgr)
summary(model_pgr)

#' Soil moisture had a positive effect on plant growth. For each unit increase in soil moisture, plant growth rate increased by 12.7 mm/week (slope = 12.7, t = 12.5, d.f. = 48, p < 0.001).
#' 
#' ### 5.5.6 FROM STATS BACK TO FIGURE
#' 
ggplot(plant_gr, aes(x = soil.moisture.content, y = plant.growth.rate)) + 
  geom_point() + 
  geom_smooth(method = 'lm') + 
  ylab("Plant Growth Rate (mm/week)") + 
  theme_bw()
#' Figure 5.6
