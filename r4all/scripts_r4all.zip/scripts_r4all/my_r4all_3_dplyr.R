#' ---
#' title: "[Getting Started with R](https://github.com/haruosuz/books/tree/master/r4all)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url)
if(!file.exists(filename)){ download.file(url = url, destfile = filename); unzip(zipfile = filename); }

#' # 3 Data Management, Manipulation, and Exploration with dplyr
library(tidyverse)
rm(list = ls())

#' ## 3.1 Summary statistics for each variable
#' ### 3.1.1 THE COMPENSATION DATA
#' ### 3.1.2 THE summary() FUNCTION

compensation <- read.csv("datasets-master/compensation.csv", stringsAsFactors=TRUE)
glimpse(compensation) # just checkin'

# get summary statistics for the compensation variables
summary(compensation)

#' ## 3.2 dplyr verbs
#' 
#' - `select()` is for selecting columns.
#' - `slice()` is for selecting rows.
#' - `filter()` is for selecting subsets of rows, conditional upon values in a column.
#' - `arrange()` is for sorting rows.
#' - `mutate()` is for creating new variables in the data frame.
#' 
#' ## 3.3 Subsetting
#' ### 3.3.1 select()
names(compensation)
select(compensation, Fruit) # use the Fruit column
select(compensation, -Fruit) # that is a minus sign

#' ### 3.3.2 slice()
slice(compensation, 2)
slice(compensation, 2:10)
slice(compensation, c(2, 3, 10))

#' ### 3.3.3 filter()
#' #### Logical operators and booleans
with(compensation, Fruit > 80)
#' #### Using filter()
#' 
#' Table 3.1
#' 
#' R logical or boolean | Meaning | Example
#' ----- | ----- | -----
#' == | Equals | filter(compensation, Fruit == 80)
#' != | Does not equal | filter(compensation, Fruit != 80)
#' <, >, >=, <= | | filter(compensation, Fruit <= 80)
#' \| | OR  | 
#'  & | AND | filter(compensation, Fruit > 80 & Root < 2.3)

# find the rows where it is true that Fruit is >80 return 
# them as a data frame
filter(compensation, Fruit > 80)
filter(compensation, Fruit > 80 | Fruit < 20)

#' ### 3.3.4 MAKING SURE YOU CAN use THE SUBSET OF DATA
lo_hi_fruit <- filter(compensation, Fruit > 80 | Fruit < 20)
lo_hi_fruit

#' ### 3.3.5 WHAT SHOULD MY SCRIPT LOOK LIKE NOW?
#' ## 3.4 Transforming
#' ### 3.4.1 mutate()

# what does compensation look like now?
head(compensation)

# use mutate
# log(Fruit) is in the column logFruit
# all of which gets put into the object compensation 
compensation <- mutate(compensation, logFruit = log(Fruit))

# first 6 rows of the new compensation
head(compensation)

#' ## 3.5 Sorting
#' ### 3.5.1 arrange()
arrange(compensation, Fruit)
#?arrange()

#' ## 3.6 Mini-summary and two top tips
#' 
# Root values from Fruit > 80 subset
select(filter(compensation, Fruit > 80), Root)

# Root values from Fruit > 80 subset
# Via piping
compensation %>%
  filter(Fruit > 80) %>% 
  select(Root)

#' ## 3.7 Calculating summary statistics about groups of your data
#' ### 3.7.1 OVERVIEW OF SUMMARIZATION
#' ### 3.7.2 METHOD 1: NESTED, NO PIPE
summarise(
  group_by(compensation, Grazing),
  meanFruit = mean(Fruit))

mean.fruit <- summarise( 
  group_by(compensation, Grazing),
  meanFruit = mean(Fruit))

#' ### 3.7.3 METHOD 2: PIPE, NO NESTING
compensation %>% 
  group_by(Grazing) %>%
  summarise(meanFruit = mean(Fruit))

#' ### 3.7.4 SUMMARIZING AND EXTENDING SUMMARIZATION
compensation %>% 
  group_by (Grazing) %>%
  summarise(
    meanFruit = mean(Fruit), 
    sdFruit = sd(Fruit))
    
#' ## 3.8 What have you learned...lots
#' you have a *permanent, repeatable, annotated, shareable, cross-platform, executable record* of what you are doing—the script.
#' 
#' ## Appendix 3a Comparing classic methods and dplyr
#' 
#' Table 3.2
#' 
#' Operation | Base R example | dplyr function
#' ----- | ----- | -----
#' Select some rows    | ?Extract | ?slice() | 
#' Select some columns | ?Extract | ?select() | 
#' Subset              | ?subset | ?filter() | 
#' Order the rows      | ?order | ?arrange() | 
#' Add a column | ?transform | ?mutate() | 
#' Define groups of data | - | ?group_by() | 
#' Summarize the data | ?aggregate; ?tapply | ?group_by(); ?summarise() | 

# Subset 
#compensation[compensation$Fruit>80,]
#subset(compensation, Fruit>80)

# Add a column
#compensation$logFruit <- log(compensation$Fruit)
#transform(compensation, logFruit=log(Fruit))

# Summarize the data
#aggregate(Fruit ~ Grazing, data = compensation, FUN = mean)
#tapply(compensation$Fruit, list(compensation$Grazing), mean)

#' ## Appendix 3b Advanced dplyr
#' 
#' 1) join()
#' - https://r4ds.had.co.nz/relational-data.html#understanding-joins
#' 
#' ![](https://d33wubrfki0l68.cloudfront.net/3abea0b730526c3f053a3838953c35a0ccbe8980/7f29b/diagrams/join-inner.png)
#' 
#' 2) group_by() + mutate()
compensation_mean_centred <- compensation %>% 
  group_by(Grazing) %>% mutate(Fruit_minus_mean = Fruit - mean(Fruit))

summarize(
  group_by(compensation_mean_centred, Grazing), 
  mean(Fruit_minus_mean))

#' 3) group_by() + do()
library(broom)
compensation_lms <- compensation %>% 
  group_by(Grazing) %>% 
  do(tidy(lm(Fruit ~ Root, data=.)))

#' - [25.6 Making tidy data with broom | R for Data Science](https://r4ds.had.co.nz/many-models.html#making-tidy-data-with-broom)
#' `broom::tidy(model)` returns a row for each coefficient in the model. Each column gives information about the estimate or its variability.

sessionInfo()
