# This script is for setting up the environment, including package installation and data import into R

#' ## 1.8 Important functionality: packages
#' - https://cran.r-project.org/mirrors.html
# Set repository options
options(repos="https://cran.asia/")

# Install R packages
install.packages("tidyverse")

# Package Description
packageVersion("tidyverse")

# Load R packages
library(tidyverse)

#' ### 5.5.4 ASSUMPTIONS FIRST
install.packages("ggfortify")

#' ## 2.2 Getting your data into R
#' - http://r4all.org/books/datasets/

# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url)
if(!file.exists(filename)){ download.file(url = url, destfile = filename); unzip(zipfile = filename); }

# Get Working Directory
getwd()

# List the Files in a Directory/Folder
list.files(path = ".")
list.files(path = "datasets-master")
