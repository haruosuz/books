#' ## 5.3 Two-sample t-test
#' ### 5.3.1 THE t-TEST DATA

#+ message = FALSE
# libraries I always use.
library(tidyverse)

# Clear the decks
rm(list = ls())

# get the data
ozone <- read.csv('datasets-master/ozone.csv', stringsAsFactors=TRUE)

# check out the data
glimpse(ozone)

#' ### 5.3.2 THE FIRST STEP: PLOT YOUR DATA
#' Figure 5.3

ggplot(ozone, aes(x = Ozone)) + 
  geom_histogram(binwidth = 10) + 
  facet_wrap(~ Garden.location, ncol = 1) + 
  theme_bw()

# standard error
se <- function(x) sqrt(var(x)/length(x))
#se <- function(x) sd(x)/sqrt(length(x))

# calculate the means and standard errors of the ozone levels in each location
ozone %>% 
  group_by(Garden.location) %>% 
  summarise(mean.Ozone = mean(Ozone), se.Ozone = se(Ozone))

#' ### 5.3.3 THE TWO-SAMPLE t-TEST ANALYSIS
#' 
t.test(Ozone ~ Garden.location, data = ozone)
?t.test

# test for equality of variance in a two-sample t-test
var.test(Ozone ~ Garden.location, data = ozone)

#' ### 5.3.4 t-TEST SUMMARY
