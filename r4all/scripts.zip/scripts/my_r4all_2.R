#' ---
#' title: "[Getting Started with R](https://github.com/haruosuz/books/tree/master/r4all)"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' # 2 Getting Your Data into R
#' ## 2.1 Getting data ready for R
#' ### 2.1.1 SETTING UP YOUR OWN DATA
#' - https://id.fnshr.info/2017/01/09/trans-tidy-data/
#' - https://id.fnshr.info/2017/01/09/tidy-data-intro/
#' 
#' #### An exercise in data preparation
#' - Top Tip 1. missing data: NA (Not Available)
#' - Top Tip 2. comma-separated values (.csv file)
#' 
#' ### 2.1.2 SOMEONE ELSE’S DATA?
#' ## 2.2 Getting your data into R
#' ### 2.2.1 IMPORTING DATA, PREPARATION
#' some annotation, the libraries, and the brain clearer
#' 
# Clear the decks
rm(list = ls())

# libraries I always use.
library(tidyverse)

#' ### 2.2.2 METHOD 1: THE IMPORT DATASET TOOL
#' Import Dataset (Figure 2.5)
#' 
#library(readr)
#compensation <- read_csv("datasets-master/compensation.csv")
#View(compensation)

#' ### 2.2.3 METHOD 2: THE file.choose() FUNCTION
#file.choose()
#' ### 2.2.4 METHOD 3: DANCING WITH THE IMPORT DEVIL
#' 
#' Session -> Set Working Directory -> Choose Directory.
#' 
#' ### 2.2.5 METHOD 4: PUT YOUR DATA IN THE SAME PLACE AS YOUR SCRIPT
#' http://r4all.org/books/datasets/
compensation <- read.csv("datasets-master/compensation.csv")

#' ## 2.3 Checking that your data are your data
names(compensation)
head(compensation)
tail(compensation)
dim(compensation)
str(compensation)

#' ### 2.3.1 YOUR FIRST INTERACTION WITH dplyr
# dplyr viewing of data
library(dplyr)

# glimpse and tbl_df
glimpse(compensation)
tbl_df(compensation)

#' ## 2.4 Basic trouble shooting while importing data
#' ## 2.5 Summing up
#' ## Appendix Advanced activity: dealing with untidy data
#' WHAT ARE UNTIDY DATA?
nasty.format <- read.csv("datasets-master/nasty format.csv")
str(nasty.format)

library(dplyr)
nasty.format <- filter(nasty.format, Bottle != "")
glimpse(nasty.format)

#' TIDYING WITH GATHER()
library(tidyr)
tidy_data <- gather(nasty.format, Date, Abundance, 4:11)
str(tidy_data)
glimpse(tidy_data)

#' CLEANING THE DATES
library(stringr)
#tidy_data <- mutate(tidy_data, Date = substr(Date, 2, 20))
tidy_data <- mutate(tidy_data, Date = str_sub(Date, 2, 20))
unique(tidy_data$Date)

library(lubridate)
tidy_data <- mutate(tidy_data, Date = dmy(Date))
glimpse(tidy_data)
str(tidy_data)

#' NOW SEE WHAT WE CAN DO!...

library(ggplot2)
ggplot(tidy_data, aes(x = Date, y = Abundance)) + 
  geom_point() + facet_wrap(~Bottle) +
  theme(axis.text.x = element_text(angle = 90)) # p.236

#' Figure 2.8


