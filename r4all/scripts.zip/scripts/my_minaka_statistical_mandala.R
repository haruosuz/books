# https://cran.r-project.org/package=RcmdrMisc
#install.packages("RcmdrMisc")
library(RcmdrMisc)

# Clear the decks
rm(list = ls())

# http://leeswijzer.org/files/StatisticalMandala.html
PlantGrowth
indexplot(PlantGrowth$weight, type="p")
Dotplot(x=PlantGrowth$weight, by=PlantGrowth$group)
stripchart(weight ~ group, data=PlantGrowth, vertical=TRUE)
Boxplot(weight ~ group, data=PlantGrowth)
scatterplot(Sepal.Width ~ Sepal.Length | Species, data=iris, regLine=FALSE, smooth=FALSE)

# Print R version and packages
sessionInfo()
