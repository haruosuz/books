#' ## 5.6 Analysis of variance: the one-way ANOVA
#' ### 5.6.1 GETTING AND PLOTTING THE DATA
#' - Plot -> Model -> Check Assumptions -> Interpret -> Plot Again workflow
# libraries I always use.
library(tidyverse)
library(ggfortify)

# Clear the decks
rm(list = ls())

# get the data
daphnia <- read.csv('datasets-master/Daphniagrowth.csv', stringsAsFactors=TRUE)

# check out the data
glimpse(daphnia)

ggplot(daphnia, aes(x = parasite, y = growth.rate)) + 
  geom_boxplot() + 
  theme_bw()
#' (Figure 5.7)

ggplot(daphnia, aes(x = parasite, y = growth.rate)) + 
  geom_boxplot() + 
  theme_bw() + 
  coord_flip()
#' (Figure 5.8)
#' 
#' ### 5.6.2 CONSTRUCT THE ANOVA
model_grow <- lm(growth.rate ~ parasite, data = daphnia)

#' ### 5.6.3 CHECK THE ASSUMPTIONS
autoplot(model_grow, smooth.colour = NA)
#' (Figure 5.9)
#' 
#' ### 5.6.4 MAKING AN INFERENCE FROM A ONE-WAY ANOVA
anova(model_grow)

#' ### 5.6.5 TREATMENT CONTRASTS
?contr.treatment
summary(model_grow)
#' Top Tip with ANOVA.
# get the mean growth rates
sumDat <- daphnia %>% 
  group_by(parasite) %>% 
  summarise(meanGR = mean(growth.rate))

sumDat

ggplot(daphnia, aes(x = parasite, y = growth.rate, color = parasite)) +
  geom_point(alpha = 0.5, size = 5) +
  geom_point(data = sumDat, 
             aes(x = parasite, y = meanGR, 
                 colour = parasite), size = 10, shape = 18) +
  coord_flip() +
  theme_bw()
#' (Figure 5.11)

