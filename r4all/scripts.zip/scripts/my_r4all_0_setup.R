# http://r4all.org/books/datasets/
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url)
download.file(url = url, destfile = filename); unzip(zipfile = filename)
compensation <- read.csv("datasets-master/compensation.csv")
dim(compensation)
str(compensation)
