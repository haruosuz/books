# http://r4all.org/books/datasets/

# Download File from the Internet
url <- "https://github.com/R4All/datasets/archive/master.zip"
filename <- basename(url)
download.file(url = url, destfile = filename); unzip(zipfile = filename)

# Get Working Directory
getwd()

# List the Files in a Directory/Folder
list.files(path = ".")
list.files(path = "datasets-master")
