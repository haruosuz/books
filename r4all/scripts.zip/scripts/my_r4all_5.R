#' ---
#' title: "Getting Started with R"
#' author: '@Haruo_Suzuki'
#' date: "`r Sys.Date()`"
#' output:
#'    html_document:
#'      toc: true
#' theme: united
#' ---

#' # Introducing Statistics in R
#' ## 5.1 Getting started doing statistics in R
#' ### 5.1.1 GETTING READY FOR SOME STATISTICS

#system("Rscript --vanilla ./my_r4all_5.2_chisq.test.R >& log.5.2_chisq.test.$(date +%F).txt")
